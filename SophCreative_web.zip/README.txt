INSTRUCCIONES
1. Extraer el ZIP.
2. Abrir la carpeta con Visual Studio Code.
3. Ejecutar con Live Server o copiar a htdocs de XAMPP.
4. Navegar entre las cuatro páginas estáticas.
